# Prompt Co-Pilot - Installation Guide

## 🚀 Quick Start

Prompt Co-Pilot is a Chrome extension that helps you improve your prompts using AI-powered refinement. This guide will walk you through installing and setting it up.

---

## 📦 Installation Steps

### Step 1: Extract the Extension

1. Extract the zip file to a location on your computer
2. Remember where you extracted it (you'll need this path in Step 3)

### Step 2: Get Your OpenAI API Key

**Important:** You need an OpenAI API key to use the AI features.

1. Go to [https://platform.openai.com/api-keys](https://platform.openai.com/api-keys)
2. Sign up or log in to your OpenAI account
3. Click "Create new secret key"
4. Give it a name (e.g., "Prompt Co-Pilot")
5. Copy the key (it starts with `sk-`)
   - ⚠️ **Important:** Copy it immediately - you won't be able to see it again!

### Step 3: Install the Extension in Chrome

1. Open Google Chrome
2. Navigate to `chrome://extensions/`
   - You can type this in the address bar or go to:
     - Chrome Menu (3 dots) → Extensions → Manage Extensions
3. Enable **"Developer mode"** (toggle in the top-right corner)
4. Click **"Load unpacked"** button
5. Select the folder where you extracted the extension
6. The extension should now appear in your extensions list!

### Step 4: Configure Your API Key

1. Click the **Prompt Co-Pilot** icon in your Chrome toolbar (✨ icon)
2. You'll see the extension popup
3. In the **"AI Configuration"** section:
   - Paste your OpenAI API key in the "OpenAI API Key" field
   - Click **"Save"**
4. You should see: **"✓ API Key saved successfully!"**

**That's it!** You're ready to use Prompt Co-Pilot.

---

## 🎯 How to Use

### Basic Usage

1. **Enable for a Website:**
   - Navigate to any website (e.g., ChatGPT, Claude, Gmail)
   - Click the extension icon
   - Toggle the switch to **"Enabled"**
   - The page will reload automatically

2. **Open the Co-Pilot:**
   - Click in any text field on the page
   - Press **`Cmd+Shift+L`** (Mac) or **`Ctrl+Shift+L`** (Windows/Linux)
   - Or right-click in the text field → Select "Improve with Co-Pilot"

3. **Improve Your Prompt:**
   - The modal opens showing your text
   - Click on any "cure pill" (e.g., "Assign Persona", "Add Format")
   - Select an improvement option
   - Watch as AI refines your prompt!
   - Click **"Apply Changes"** to update the text field

### AI Modes

You can choose between two AI modes:

- **⚡ Fast Mode** (GPT-4o Mini): Quick refinements, cost-effective
- **🧠 Expert Mode** (GPT-4o): Advanced reasoning, deeper analysis

Switch modes by clicking the extension icon → Toggle between Fast/Expert buttons

---

## 🔧 Troubleshooting

### Extension won't load
- Make sure you extracted all files from the zip
- Check that you selected the correct folder (the one containing `manifest.json`)
- Try disabling and re-enabling Developer mode

### API Key not working
- Verify your key starts with `sk-`
- Check that you copied the entire key (no spaces before/after)
- Make sure your OpenAI account has credits/usage available
- Try generating a new API key

### Modal doesn't open
- Make sure extension is enabled for the website (check extension icon)
- Click inside a text field before pressing the keyboard shortcut
- Check browser console for errors (F12 → Console tab)

### Text doesn't update
- Try clicking "Apply Changes" again
- Some websites may require page refresh after enabling extension
- Check that the text field is editable (not disabled)

### Keyboard shortcut doesn't work
- Some websites may use the same shortcut
- Try the right-click menu instead
- Check Chrome shortcuts: `chrome://extensions/shortcuts`

---

## 📋 Supported Websites

Prompt Co-Pilot works on most websites with text inputs:

✅ **AI Chat Platforms:**
- ChatGPT (chat.openai.com)
- Claude (claude.ai)
- Perplexity (perplexity.ai)

✅ **Email & Messaging:**
- Gmail
- Outlook
- Slack

✅ **Document Editors:**
- Google Docs
- Notion
- Confluence

✅ **Social Media:**
- Twitter/X
- LinkedIn
- Facebook

✅ **Any website with text fields!**

---

## 💡 Tips & Best Practices

1. **Start with a clear prompt:** Even basic prompts work better with AI refinement
2. **Use multiple improvements:** Apply improvements one at a time to see the effect
3. **Choose the right mode:** Use Fast mode for quick prompts, Expert mode for complex tasks
4. **Save custom prompts:** Create reusable prompts for common tasks
5. **Experiment:** Try different personas and formats to see what works best

---

## 🔒 Privacy & Security

- ✅ Your API key is stored locally in your browser
- ✅ Prompts are sent only to OpenAI API (not to any other servers)
- ✅ No data is stored or tracked by the extension
- ✅ You control which websites have access

---

## 📞 Need Help?

If you encounter issues:

1. Check the Troubleshooting section above
2. Make sure you're using the latest version of Chrome
3. Try reloading the extension (`chrome://extensions/` → Click refresh icon)
4. Check browser console for error messages (F12)

---

## 🎉 Ready to Go!

You're all set! Start improving your prompts with AI-powered refinement.

**Keyboard Shortcut:** `Cmd+Shift+L` (Mac) or `Ctrl+Shift+L` (Windows/Linux)

Enjoy using Prompt Co-Pilot! ✨

